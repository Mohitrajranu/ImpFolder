package rc.legostore.model;

public enum LegoSetDifficulty {
    NOT_AVAILABLE,
    EASY,
    MEDIUM,
    HARD
}

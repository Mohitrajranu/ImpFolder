package rc.legostore.model;

public enum PaymentType {
    CreditCard,
    PayPal,
    Cash
}
